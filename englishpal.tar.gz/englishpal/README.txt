Author: Hui Lan  <lanhui@zjnu.edu.cn>


Purpose
-------

This software helps English learners boost their vocabulary.



Usage
-----

Open a terminal, and type the following command: python3 wordfreqWEB.py

Open a web browser (e.g., Firefox), enter the following address: http://127.0.0.1:5000/



Dependencies
------------

The Flask module.  Check https://pypi.org/project/Flask/ on how to install it.



12 Sep 2019

